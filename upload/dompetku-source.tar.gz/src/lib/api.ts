// API client helpers for the finance app
import type {
  Account,
  AccountInput,
  AnalyticsData,
  Budget,
  BudgetInput,
  BudgetStatus,
  Category,
  CategoryInput,
  ChatMessage,
  Challenge,
  ChallengeParticipation,
  DailyAllowanceInfo,
  DashboardData,
  Debt,
  DebtInput,
  ExportPreview,
  ExportTemplate,
  ExportTemplateInput,
  FriendDebt,
  FriendDebtInput,
  Goal,
  GoalInput,
  Installment,
  InstallmentInput,
  NotificationItem,
  NotificationPayload,
  RecurringInput,
  RecurringTransaction,
  ShareLink,
  ShareLinkInput,
  SplitBill,
  SplitBillInput,
  StudentProfile,
  StudentProfileInput,
  Tag,
  Transaction,
  TransactionGroup,
  TransactionGroupInput,
  TransactionInput,
  TransactionTemplate,
  TransactionTemplateInput,
  TransferInput,
} from "@/lib/types";

// Re-export notification types so legacy callers using `import { NotificationItem } from "@/lib/api"` keep working.
export type { NotificationItem, NotificationPayload };

async function request<T>(
  url: string,
  options?: RequestInit
): Promise<T> {
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options?.headers ?? {}),
    },
  });
  if (!res.ok) {
    let message = `Permintaan gagal (${res.status})`;
    try {
      const body = await res.json();
      if (body?.error) message = body.error;
      else if (body?.message) message = body.message;
    } catch {
      // ignore
    }
    throw new Error(message);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export const api = {
  // Transactions
  listTransactions: (params?: {
    type?: string;
    categoryId?: string;
    accountId?: string;
    search?: string;
    from?: string;
    to?: string;
    tag?: string;
    limit?: number;
  }) => {
    const sp = new URLSearchParams();
    if (params?.type && params.type !== "ALL") sp.set("type", params.type);
    if (params?.categoryId && params.categoryId !== "ALL")
      sp.set("categoryId", params.categoryId);
    if (params?.accountId && params.accountId !== "ALL")
      sp.set("accountId", params.accountId);
    if (params?.search) sp.set("search", params.search);
    if (params?.from) sp.set("from", params.from);
    if (params?.to) sp.set("to", params.to);
    if (params?.tag) sp.set("tag", params.tag);
    if (params?.limit) sp.set("limit", String(params.limit));
    const qs = sp.toString();
    return request<Transaction[]>(`/api/transactions${qs ? `?${qs}` : ""}`);
  },
  createTransaction: (data: TransactionInput) =>
    request<Transaction>("/api/transactions", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateTransaction: (id: string, data: TransactionInput) =>
    request<Transaction>(`/api/transactions/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteTransaction: (id: string) =>
    request<void>(`/api/transactions/${id}`, { method: "DELETE" }),

  // Categories
  listCategories: (type?: string) => {
    const qs = type ? `?type=${type}` : "";
    return request<Category[]>(`/api/categories${qs}`);
  },
  createCategory: (data: CategoryInput) =>
    request<Category>("/api/categories", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  deleteCategory: (id: string) =>
    request<void>(`/api/categories/${id}`, { method: "DELETE" }),

  // Accounts
  listAccounts: () => request<Account[]>("/api/accounts"),
  createAccount: (data: AccountInput) =>
    request<Account>("/api/accounts", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateAccount: (id: string, data: Partial<AccountInput>) =>
    request<Account>(`/api/accounts/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteAccount: (id: string) =>
    request<void>(`/api/accounts/${id}`, { method: "DELETE" }),
  transfer: (data: TransferInput) =>
    request<{ message: string }>("/api/accounts/transfer", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  // Budgets
  listBudgets: () => request<Budget[]>("/api/budgets"),
  createBudget: (data: BudgetInput) =>
    request<Budget>("/api/budgets", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateBudget: (id: string, data: BudgetInput) =>
    request<Budget>(`/api/budgets/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteBudget: (id: string) =>
    request<void>(`/api/budgets/${id}`, { method: "DELETE" }),
  budgetStatuses: () =>
    request<BudgetStatus[]>("/api/budgets/status"),

  // Goals
  listGoals: () => request<Goal[]>("/api/goals"),
  createGoal: (data: GoalInput) =>
    request<Goal>("/api/goals", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateGoal: (id: string, data: Partial<GoalInput>) =>
    request<Goal>(`/api/goals/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteGoal: (id: string) =>
    request<void>(`/api/goals/${id}`, { method: "DELETE" }),

  // Recurring
  listRecurring: () => request<RecurringTransaction[]>("/api/recurring"),
  createRecurring: (data: RecurringInput) =>
    request<RecurringTransaction>("/api/recurring", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateRecurring: (id: string, data: Partial<RecurringInput>) =>
    request<RecurringTransaction>(`/api/recurring/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteRecurring: (id: string) =>
    request<void>(`/api/recurring/${id}`, { method: "DELETE" }),

  // Tags
  listTags: () => request<Tag[]>("/api/tags"),

  // Debts
  listDebts: () => request<Debt[]>("/api/debts"),
  createDebt: (data: DebtInput) =>
    request<Debt>("/api/debts", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateDebt: (id: string, data: Partial<DebtInput>) =>
    request<Debt>(`/api/debts/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteDebt: (id: string) =>
    request<void>(`/api/debts/${id}`, { method: "DELETE" }),
  settleDebt: (id: string) =>
    request<Debt>(`/api/debts/${id}/settle`, { method: "POST" }),

  // Installments
  listInstallments: () => request<Installment[]>("/api/installments"),
  createInstallment: (data: InstallmentInput) =>
    request<Installment>("/api/installments", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  deleteInstallment: (id: string) =>
    request<void>(`/api/installments/${id}`, { method: "DELETE" }),

  // Transaction Templates
  listTemplates: () => request<TransactionTemplate[]>("/api/templates"),
  createTemplate: (data: TransactionTemplateInput) =>
    request<TransactionTemplate>("/api/templates", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  deleteTemplate: (id: string) =>
    request<void>(`/api/templates/${id}`, { method: "DELETE" }),

  // Transaction Groups (events)
  listGroups: () => request<TransactionGroup[]>("/api/transaction-groups"),
  createGroup: (data: TransactionGroupInput) =>
    request<TransactionGroup>("/api/transaction-groups", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  deleteGroup: (id: string) =>
    request<void>(`/api/transaction-groups/${id}`, { method: "DELETE" }),

  // Transaction actions
  duplicateTransaction: (id: string) =>
    request<Transaction>(`/api/transactions/${id}/duplicate`, {
      method: "POST",
    }),
  togglePin: (id: string) =>
    request<Transaction>(`/api/transactions/${id}/pin`, { method: "POST" }),

  // Dashboard
  getDashboard: (month?: string) => {
    const qs = month ? `?month=${month}` : "";
    return request<DashboardData>(`/api/dashboard${qs}`);
  },

  // Analytics
  getAnalytics: (month?: string) => {
    const qs = month ? `?month=${month}` : "";
    return request<AnalyticsData>(`/api/analytics${qs}`);
  },

  // Settings
  getSettings: () => request<Record<string, string>>("/api/settings"),
  updateSetting: (key: string, value: string) =>
    request<{ message: string }>("/api/settings", {
      method: "PUT",
      body: JSON.stringify({ key, value }),
    }),

  // AI
  chat: (messages: ChatMessage[]) =>
    request<{ reply: string }>("/api/ai/chat", {
      method: "POST",
      body: JSON.stringify({ messages }),
    }),
  receiptScan: (imageBase64: string) =>
    request<{
      merchant?: string;
      date?: string;
      total?: number;
      items?: string[];
      category?: string;
    }>("/api/ai/receipt", {
      method: "POST",
      body: JSON.stringify({ image: imageBase64 }),
    }),
  insights: () =>
    request<{ insights: string[] }>("/api/ai/insights"),

  // Import
  importCsv: (rows: Array<Record<string, string>>) =>
    request<{ imported: number; skipped: number; errors: string[] }>(
      "/api/import/csv",
      {
        method: "POST",
        body: JSON.stringify({ rows }),
      }
    ),

  // Export
  exportTransactionsUrl: (params?: {
    type?: string;
    from?: string;
    to?: string;
  }) => {
    const sp = new URLSearchParams();
    if (params?.type && params.type !== "ALL") sp.set("type", params.type);
    if (params?.from) sp.set("from", params.from);
    if (params?.to) sp.set("to", params.to);
    const qs = sp.toString();
    return `/api/export/transactions${qs ? `?${qs}` : ""}`;
  },
  backupUrl: () => "/api/export/backup",
  // Enhanced export with preview + multi-format
  exportPreview: (data: {
    scope: Record<string, unknown>;
    fields?: string[];
    options?: Record<string, unknown>;
  }) =>
    request<ExportPreview>("/api/export/preview", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  exportPdfUrl: () => "/api/export/pdf",
  exportExcelUrl: () => "/api/export/excel",
  exportCsvUrl: () => "/api/export/csv",
  exportJsonUrl: () => "/api/export/json",
  // Export templates
  listExportTemplates: () =>
    request<ExportTemplate[]>("/api/export/templates"),
  createExportTemplate: (data: ExportTemplateInput) =>
    request<ExportTemplate>("/api/export/templates", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateExportTemplate: (id: string, data: Partial<ExportTemplateInput>) =>
    request<ExportTemplate>(`/api/export/templates/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteExportTemplate: (id: string) =>
    request<void>(`/api/export/templates/${id}`, { method: "DELETE" }),
  // Hide transaction
  toggleHideTransaction: (id: string) =>
    request<Transaction>(`/api/transactions/${id}/hide`, { method: "POST" }),

  // Seed
  seed: () => request<{ message: string }>("/api/seed", { method: "POST" }),
  runRecurring: () =>
    request<{ generated: number }>("/api/recurring/run", { method: "POST" }),

  // Security
  getSecurity: () => request<Record<string, string>>("/api/security"),
  updateSecurity: (key: string, value: string) =>
    request<{ message: string }>("/api/security", {
      method: "PUT",
      body: JSON.stringify({ key, value }),
    }),
  updateSecurityBulk: (settings: Record<string, string>) =>
    request<{ message: string; saved: number }>("/api/security/bulk", {
      method: "PUT",
      body: JSON.stringify({ settings }),
    }),
  listAudit: (params?: { limit?: number; offset?: number; action?: string }) => {
    const sp = new URLSearchParams();
    if (params?.limit) sp.set("limit", String(params.limit));
    if (params?.offset) sp.set("offset", String(params.offset));
    if (params?.action) sp.set("action", params.action);
    const qs = sp.toString();
    return request<{
      data: Array<{
        id: string;
        action: string;
        detail: string | null;
        ipAddress: string | null;
        userAgent: string | null;
        success: boolean;
        createdAt: string;
      }>;
      total: number;
      limit: number;
      offset: number;
    }>(`/api/audit${qs ? `?${qs}` : ""}`);
  },
  logAudit: (action: string, detail?: string, success = true, fingerprint?: string) =>
    request<{ message: string }>("/api/audit", {
      method: "POST",
      body: JSON.stringify({ action, detail, success, fingerprint }),
    }),
  // Biometric
  listBiometric: () =>
    request<Array<{ id: string; name: string; credentialId: string; createdAt: string }>>("/api/biometric"),
  registerBiometric: (data: { name: string; credentialId: string; publicKey: string; counter: number }) =>
    request("/api/biometric/register", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  verifyBiometric: (credentialId: string, counter: number) =>
    request<{ verified: boolean }>("/api/biometric/verify", {
      method: "POST",
      body: JSON.stringify({ credentialId, counter }),
    }),
  deleteBiometric: (id: string) =>
    request("/api/biometric", { method: "DELETE", body: JSON.stringify({ id }) }),
  // Trusted devices
  listTrustedDevices: () =>
    request<Array<{ id: string; name: string; fingerprint: string; trustedUntil: string; lastSeen: string; createdAt: string }>>("/api/trusted-devices"),
  addTrustedDevice: (data: { name: string; fingerprint: string; trustedDays: number }) =>
    request("/api/trusted-devices", { method: "POST", body: JSON.stringify(data) }),
  revokeTrustedDevice: (id: string) =>
    request(`/api/trusted-devices/${id}`, { method: "DELETE" }),
  // Panic wipe
  panicWipe: () => request<{ message: string; wipedAt: string }>("/api/panic-wipe", { method: "POST" }),

  // Share Links
  listShares: () => request<ShareLink[]>("/api/shares"),
  createShare: (data: ShareLinkInput) =>
    request<ShareLink>("/api/shares", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  updateShare: (id: string, data: Partial<ShareLinkInput>) =>
    request<ShareLink>(`/api/shares/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteShare: (id: string) =>
    request<void>(`/api/shares/${id}`, { method: "DELETE" }),
  revokeShare: (token: string) =>
    request<{ message: string }>(`/api/shares/${token}/revoke`, {
      method: "POST",
    }),
  cloneShare: (token: string) =>
    request<ShareLink>(`/api/shares/${token}/clone`, {
      method: "POST",
    }),

  // Student Profile
  getStudentProfile: () => request<StudentProfile | null>("/api/student-profile"),
  updateStudentProfile: (data: StudentProfileInput) =>
    request<StudentProfile>("/api/student-profile", {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  // Daily Allowance Info
  getDailyAllowance: () =>
    request<DailyAllowanceInfo>("/api/student-profile/daily"),

  // Challenges
  listChallenges: () => request<Challenge[]>("/api/challenges"),
  joinChallenge: (challengeId: string) =>
    request<ChallengeParticipation>("/api/challenges/join", {
      method: "POST",
      body: JSON.stringify({ challengeId }),
    }),
  listChallengeParticipations: () =>
    request<ChallengeParticipation[]>("/api/challenges/participations"),
  abandonChallenge: (participationId: string) =>
    request<void>(`/api/challenges/participations/${participationId}`, {
      method: "DELETE",
    }),

  // Split Bills
  listSplitBills: () => request<SplitBill[]>("/api/split-bills"),
  createSplitBill: (data: SplitBillInput) =>
    request<SplitBill>("/api/split-bills", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  deleteSplitBill: (id: string) =>
    request<void>(`/api/split-bills/${id}`, { method: "DELETE" }),
  settleSplitBill: (id: string) =>
    request<SplitBill>(`/api/split-bills/${id}/settle`, { method: "POST" }),
  markParticipantPaid: (participantId: string) =>
    request<void>(`/api/split-bills/participants/${participantId}/paid`, {
      method: "POST",
    }),

  // Friend Debts
  listFriendDebts: () => request<FriendDebt[]>("/api/friend-debts"),
  createFriendDebt: (data: FriendDebtInput) =>
    request<FriendDebt>("/api/friend-debts", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  settleFriendDebt: (id: string) =>
    request<FriendDebt>(`/api/friend-debts/${id}/settle`, { method: "POST" }),
  deleteFriendDebt: (id: string) =>
    request<void>(`/api/friend-debts/${id}`, { method: "DELETE" }),

  // AI Jajan Check
  jajanCheck: (amount: number) =>
    request<{ reply: string; canAfford: boolean; remaining: number }>(
      "/api/ai/jajan-check",
      { method: "POST", body: JSON.stringify({ amount }) }
    ),

  // Notifications
  listNotifications: () =>
    request<NotificationItem[]>("/api/notifications"),
  createNotification: (data: NotificationPayload) =>
    request<NotificationItem>("/api/notifications", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  markNotificationRead: (id: string) =>
    request<NotificationItem>(`/api/notifications/${id}/read`, {
      method: "POST",
    }),
  deleteNotification: (id: string) =>
    request<void>(`/api/notifications/${id}`, { method: "DELETE" }),

  // Installment Payments (cicilan/partial payments)
  listInstallmentPayments: (params?: { entityType?: string; entityId?: string }) => {
    const sp = new URLSearchParams();
    if (params?.entityType) sp.set("entityType", params.entityType);
    if (params?.entityId) sp.set("entityId", params.entityId);
    const qs = sp.toString();
    return request<Array<{
      id: string;
      entityType: string;
      entityId: string;
      amount: number;
      date: string;
      note: string | null;
      createdAt: string;
    }>>(`/api/installment-payments${qs ? `?${qs}` : ""}`);
  },
  createInstallmentPayment: (data: {
    entityType: string;
    entityId: string;
    amount: number;
    date?: string;
    note?: string;
    participantId?: string;
  }) =>
    request("/api/installment-payments", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  deleteInstallmentPayment: (id: string) =>
    request<void>(`/api/installment-payments/${id}`, { method: "DELETE" }),
};
